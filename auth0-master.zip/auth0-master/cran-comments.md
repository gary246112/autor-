## Test environments

* local Ubuntu 18.04
* Ubuntu 18.04 (on travis-ci), R-release
* r-hub (check_for_cran)

## R CMD check results

0 errors | 0 warnings | 0 notes

## Version 0.2.1

Fixed a major bug re-adding remote URL parameter and a new auth0 local 
  option on startup.

## Reverse dependencies

There are no reverse dependencies.

---

* FAILURE SUMMARY

    * checking CRAN incoming feasibility ... NOTE
    Maintainer: 'Julio Trecenti <julio.trecenti@gmail.com>'
    
    Days since last update: 5
